exports.getAllUser = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'message'
  });
};
exports.updateArticle = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'message'
  });
};
exports.getUser = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'message'
  });
};
exports.updateUser = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'message'
  });
};
exports.createUser = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'message'
  });
};
exports.deleteUser = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'message'
  });
};
